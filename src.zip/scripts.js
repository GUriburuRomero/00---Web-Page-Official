function msg(){
    let ref = document.getElementById("cont");
    window.alert("Gracias por querer contactar con nosotros")
}